import time
import random

Desert_Monsters = ['Fox', 'The scorpion', 'Snake', 'Dog']
Cave_Monsters = ['Bear', 'Rabbit', 'Lion', 'Wolf', 'Monkey']

Places = ['Cave', 'Desert']
Weapons = ['Spear', 'Knife', 'Gun', 'Rock']


Game_Result = ['Win', 'Lose']



def PrintSleep(msg, seconds):
    print(msg + '\n')
    time.sleep(seconds)




PrintSleep('***** WELCOME TO MY GAME ***** ' , 2)

PrintSleep('write this game for a course in udacity ' , 2)
PrintSleep('ARE YOU READY TO PLAY ....... ' , 2)
name = input('Please Enter Your Name To Start Game \n')
time.sleep(1)
print('Choose Witch Place you want to play \n')
time.sleep(1)
for place in Places:
    print(place)
    time.sleep(1)
Choise = ''
while Choise not in Places:
    msg = '\n Give me your choise \n for Cave write c or Cave or 1\n for desert write desert or d or 2 \n'
    Choise=input(msg)
    if Choise.lower() == 'cave'.lower() or Choise.lower() == 'C'.lower() or  Choise == '1':
        Choise = 'Cave'
    elif Choise.lower() == 'Desert'.lower() or Choise.lower() == 'D'.lower() or  Choise == '2':
        Choise= 'Desert'
    else:
        Choise = ''
time.sleep(2)
print('you have a weapon ')
weaponchoosed = random.choice(Weapons)
print(weaponchoosed)
changerequest = input('would you like to change weapon\n')
if changerequest == 'yes':
    weaponchoosed=random.choice(Weapons)
    print(weaponchoosed)
print('\nyou now in ' + Choise + ' and you have a weapon ' + weaponchoosed)
time.sleep(1)
print('now you see fornt of you ')
if Choise == 'Cave':
    print(random.choice(Cave_Monsters))
if Choise == 'Desert':
    print(random.choice(Desert_Monsters))

time.sleep(3)
PrintSleep('\nUse weapon to kill monster' , 2)

print('you ' + random.choice(Game_Result))
time.sleep(3)

print('\n')

print ('****** END GAME *****')
